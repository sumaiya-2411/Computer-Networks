import socket 
port = 6060 
hostname = socket.gethostname() 
host_ip = socket.gethostbyname (hostname) 
size=16
format='utf-8'
server_socket_addr = (host_ip, port) 
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
server.bind(server_socket_addr) 
server.listen() 
print("Server is now ready to listen.")

def vowel_count(msg):
    vowels = 'aeiouAEIOU'
    count = 0
    for char in msg:
        if char in vowels:
            count += 1
    return count

while True:
    conn,addr=server.accept()
    print("connected to",addr)

    connected=True
    while connected:
        msg_ln=conn.recv(size).decode(format)
        if not msg_ln:
            connected=False
            break
        print("lenth of the messege:",msg_ln)
        
        msg_ln=int(msg_ln)
        msg=conn.recv(msg_ln).decode(format)
        print(msg)
        if msg == 'End':
            connected=False
            break
        else:
            vowel=vowel_count(msg)
            if vowel==0:
                conn.send('Not Enough Vowels'.encode(format))
            elif vowel<3:
                conn.send('Enough Vowels I guess'.encode(format))
            else:
                conn.send('Too Many Vowels'.encode(format))
    conn.close()