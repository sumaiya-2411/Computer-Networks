import socket

port = 6060 
size= 16
hostname = socket.gethostname()
host_ip = socket.gethostbyname(hostname) 
format = 'utf-8'
server_socket_addr = (host_ip, port) 
disconnected_msg = 'End'

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
client.connect(server_socket_addr) 

def msg_to_send(msg):

    encoded_msg = msg.encode(format)
    msg_ln = len(encoded_msg)
    msg_ln = str(msg_ln).encode(format)
    msg_ln +=b' '*(size-len(msg_ln))
    
    client.send(msg_ln)
    
    client.send(encoded_msg)
    
    if msg != disconnected_msg:
        print(client.recv(2048).decode(format))

msg_to_send('Hello world')
msg_to_send('Hi')
msg_to_send('bcd')
msg_to_send(disconnected_msg)
client.close()