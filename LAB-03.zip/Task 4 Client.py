import socket

port = 6060 
size= 16
hostname = socket.gethostname()
host_ip = socket.gethostbyname(hostname) 
format = 'utf-8'
server_socket_addr = (host_ip, port) 
disconnected_msg = 'End'

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
client.connect(server_socket_addr) 


hours = input("Enter the number of hours worked: ")

encoded = hours.encode(format)
msg_len = str(len(encoded)).encode(format)
msg_len += b' ' * (size- len(msg_len)) 

client.send(msg_len)
client.send(encoded)

response = client.recv(2048).decode(format)
print("Server:", response)
client.close()