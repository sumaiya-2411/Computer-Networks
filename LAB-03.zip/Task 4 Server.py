import socket 
port = 6060 
hostname = socket.gethostname() 
host_ip = socket.gethostbyname (hostname) 
size=16
format='utf-8'
server_socket_addr = (host_ip, port) 
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
server.bind(server_socket_addr) 
server.listen() 
print("Server is ready to listen.")

while True:
    conn,addr=server.accept()
    print("connected to",addr)

    connected=True
    while connected:
        msg_ln=conn.recv(size).decode(format)
        if not msg_ln:
            connected=False
            break
        print("lenth of the messege:",msg_ln)
        
        msg_ln=int(msg_ln)
        msg=conn.recv(msg_ln).decode(format)
        hours=int(msg)
        print(f"Received hours: {hours}")

        if hours <= 40:
            salary = hours * 200
        else:
            salary = 8000 + (hours - 40) * 300

        conn.send(f"Salary is: Tk {salary}".encode(format))
        print(f"Sent salary: Tk {salary}")
    conn.close()