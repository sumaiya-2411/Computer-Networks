import socket 
import threading

port = 6060 
hostname = socket.gethostname() 
host_ip = socket.gethostbyname (hostname) 
size=16
format='utf-8'
server_socket_addr = (host_ip, port) 
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
server.bind(server_socket_addr) 
server.listen() 
print("Server is ready to listen.")

def vowel_count(msg):
    vowels = 'aeiouAEIOU'
    count = 0
    for char in msg:
        if char in vowels:
            count += 1
    return count
def handle_client(conn, addr):
    print("Connected to", addr)
    connected = True
    while connected:
        try:
            msg_ln_raw = conn.recv(size)
            if not msg_ln_raw:
                break
            msg_ln = int(msg_ln_raw.decode(format).strip())

            msg = conn.recv(msg_ln).decode(format)
            print(f"Message from {addr}: {msg}")

            if msg == 'End':
                connected = False
                break

            conn.send('Message has been received'.encode(format))

            v_count = vowel_count(msg)
            if v_count == 0:
                conn.send('Not Enough Vowels'.encode(format))
            elif v_count <= 2:
                conn.send('Enough Vowels I guess'.encode(format))
            else:
                conn.send('Too Many Vowels'.encode(format))
        except Exception as e:
            print(f"Error with client {addr}: {e}")
            break
    conn.close()
    print(f"Connection closed: {addr}")

while True:
    conn, addr = server.accept()
    thread = threading.Thread(target=handle_client, args=(conn, addr))
    thread.start()
    print(f"[ACTIVE CONNECTIONS] {threading.active_count() - 1}")