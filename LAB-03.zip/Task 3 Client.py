import socket

port = 6060 
size= 16
hostname = socket.gethostname()
host_ip = socket.gethostbyname(hostname) 
format = 'utf-8'
server_socket_addr = (host_ip, port) 
disconnected_msg = 'End'

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
client.connect(server_socket_addr) 

while True:
    msg = input("Enter your message to send to server (or type 'End' to exit): ")

    encoded_msg = msg.encode(format)
    msg_ln = len(encoded_msg)
    msg_ln = str(msg_ln).encode(format)
    msg_ln +=b' '*(size-len(msg_ln))
    
    client.send(msg_ln)
    
    client.send(encoded_msg)
    
    if msg == disconnected_msg:
        break
    print('Server:',client.recv(2048).decode(format))
    print('Server:',client.recv(2048).decode(format))
client.close()